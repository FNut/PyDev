# -*- coding: utf-8 -*-

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import  ScreenManager, Screen
from kivy.clock import Clock

from kivymd.app import MDApp

from functools import partial


class Home_Screen(Screen):
	input_znac = []
	def input_oper(self, key):
		self.input_znac.append(key)
		self.display_id.text = str(self.input_znac).replace('[','').replace(']','').replace(',','').replace("'",'').replace(' ','')
		self.pred_res()

	def clear_input_znac(self, key):
		try:
			if key == 'clien':
				self.input_znac.clear()
			elif key == 'remove':
				self.input_znac.pop(-1)
				self.display_id.text = str(self.input_znac).replace('[','').replace(']','').replace(',','').replace("'",'')
				self.pred_res()
				if len(self.input_znac) < 2:
					self.pred_res_id.text = '0'
		except:
			self.display_id.text = '0'
			return 	
		
	def pred_res(self):
		try:
			if len(self.input_znac) > 2:
				resulr = eval(''.join(self.input_znac))
				self.pred_res_id.text = str(resulr)
				big = 15
				time_big = 0
				for x in range(0,10):
					big = big+1
					time_big = time_big+0.02
					Clock.schedule_once(partial(self.anim_text, big, x), time_big)
		except:
			return
	
	def anim_text(self, big, step, *args):
		self.pred_res_id.font_size = f'{big}sp'
		if step == 9:
			self.pred_res_id.font_size = '15sp'

	def ravno(self):
		try:
			resulr = eval(''.join(self.input_znac))
			self.display_id.text = str(resulr)
			self.input_znac.clear()
			self.input_znac.append(str(resulr))
		except IndexError:
			self.display_id.text = 'Ошибка вводв.'
		except:
			return 


class ScreenManager(ScreenManager):
	pass
	
	
class ScreenApp(MDApp):
	def build(self):
		ScreenManager()


if __name__ == '__main__':
	ScreenApp().run()